/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>
int main()
{
    
//     int i=5;
//     while(i>=1){
//         int j=5;
//         while(j>=i){
//             printf("%d",j);
            
//             --j;
            
//         }
//         printf("\n");
//         --i;
//     }
    
    // int i=1,k=1;
    // while(i<=5){
    //     int j=1;
    //     while(j<=i){
    //         printf("%d",k++);
            
    //         j++;
            
    //     }
    //      i++;
    //     printf("\n");
        
    // }
    
    
  
    
    
    // int i=5;
    // while(i>=1){
    //     int j=5;
    //     while(j>=i){
    //         printf("%d",i);
            
    //         --j;
            
    //     }
        
    //     printf("\n");
    //     --i;
    // }
    
    
    // int i=1;
    // while(i<=5){
    //     int j=1;
    //     while(j<=i){
    //         printf("%d",i);
            
    //         ++j;
            
    //     }
    //     printf("\n");
    //     ++i;
    // }
    
    // int i=1;
    // while(i<=5){
    //     int j=1;
    //     while(j<=i){
    //         printf("%d",j);
            
    //         ++j;
            
    //     }
    //     printf("\n");
    //     ++i;
    // }
    
//     int i, j;
  
//         for (i = 1; i <= 5; ++i) {
//         for (j = 1; j <= i; ++j) {
//          printf("%d ", j);
//       }
//       printf("\n");
//   }
    // PETTON
    //  int n,i=0;
    // float r=0.5,d=0.5;
    // printf("Enter number:");
    // scanf("%d",&n);
    
    // do{
    //     printf("%.1f, ",r);
        
    //     i++;
    //     r+=d;
    //     d+=1;
    // }while(i<=n);
    
        
        
    
    
    // int n;
    // float a=0.5,b=0.5;
    // printf("Enter number:");
    // scanf("%d",&n);
    
    // for(int i=0;i<=n;i++)
    // {
    //     printf("%.1f, ",a);
    //     a+=b;
    //     b+=1;
    // }
    
    
    int i=1,j=0,k=1,n,m;
    
    printf("enter number:");
    scanf("%d\t",&n);
    
    do{
        m=k+j;
        printf("%d\t",m);
        k=j;
        j=m;
        i++;
    }while(i<=n);
    
    // char i=65;
    // do
    // {
    //     if(i%2==1)
    //     printf("%c\n",i);
    //     i++;
        
    // }while(i<=90);
    
    
    
    // int n, i=1;


    // printf("Enter the length of Series: ");
    // scanf("%d", &n);
    
    // while(n!=0)
    // {
    // printf("%d ", i);
    // i*=2;
    // n-=1;   
    // }
    
    // int i=1,n;
    // printf("enter number:");
    // scanf("%d",&n);
    // while(i<=n)
    // {
    //     if(i%2!=0)
    //     {
    //     printf("%d ", i);
    //     }
    //     else
    //     {
    //     printf("%d ", i*i);
    //     }
    //     i++;    
    // }
    
    
    
    // int i=1,n;
    // printf("enter number:");
    // scanf("%d",&n);
    // while(i<=n)
    // {
    //     printf("%d ", i * i);
    //     i++;    
    // }
    
    
    // int i,n;
    // printf("Enther even number:");
    // scanf("%d",&n);
    
    //   while(i <= n)
    //  {
    //       if(i %2==0)
    //       {
    //           printf("%d ",i);
    //       }
    //       i++;
    //  }
     
    // int n=5;
     
    //  int i = 1;
     
    //  while(i <= n)
    //  {
    //       if(i % 2 != 0)
    //       {
    //           printf("%d ",i);
    //       }
    //       i++;
    //  }
    
    
    // int i=1,c;
    // while(i<=10)
    
    //     {
                    
    //         printf("%d\n",i);
    
    //         c=c+i;
            
    //         i++;
    
    //     }
    
    //         printf("%d ",c);
    

    
    
    // char ch='A';
    
    // while(ch<='Z')
    // {
    //     printf("%c-%c\n", ch,ch+32);
    //     ch++;
    // }
    
    
    // char ch = 'A';  
  
    // while(ch <= 'Z')  
    // {  
    //     printf("%c-", ch);
    //     printf("%d \n", ch);  
    //     ch++;  
    // }  
    // printf("\n"); 
    
    
    // char ch = 'A';  
  

    // while(ch <= 'Z')  
    // {  
    //     printf("%c ", ch);  
    //     ch++;  
    // }  
    // printf("\n"); 
    
    
    // int n=50,i=1;
     
    //  while(i <= n)
    //  {
    //       if(i %2==0)
    //       {
    //           printf("%d ",i);
    //       }
    //       i++;
    //  }
     
    // int n=50;
     
    //  int i = 1;
     
    //  while(i < n)
    //  {
    //       if(i % 2 != 0)
    //       {
    //           printf("%d ",i);
    //       }
    //       i++;
    //  }
    
    
    // int i,n;
    // printf("Enter value of n:");
    // scanf("%d",&n);
    // i=-n;
    // while(i<=n)
    // {
    //     printf("%d ",i);
    //     i++;
    // }
        
    

    // int i;
    // printf("enter number:");
    // scanf("%d",&i);
    
    
    // while(i>=1)
    // {
    //     printf("%d\n",i);
    //     i--;
    // }
    
    
    // int i=1,n;
    // printf("enter the number:");
    // scanf("%d",&n);
    // while(i<=n)
    // {
    //     printf("%d,",i);
    //     i++;
    // }
    
    
    
    // int i=51;
    // while(i<=99)
    // {
    //     printf("%d,",i);
    //     i++;
    // }
    
    // int i=10;
    // while(i>=1)
    // {
    //     printf("%d\n",i);
    //     i--;
    // }
    
    
    // int i=1;
    // while(i<=10)
    // {
    //     printf("%d\n",i);
    //     i++;
    // }
    return 0;   
    
}   


 





