/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a;
    printf("Enter the valur:\n");
    scanf("%d",&a);
    
    switch(a){
        case 10;
        printf("The value is 10\n");
        
        case 12;
        printf("The value is 12\n");
        
        case 15;
        printf("The value is 15\n");
        
        default;
        printf("The value is not 10,12, or 15\n");
        
    }

    return 0;
}
