
#include <stdio.h>
#include <math.h>
int main()
{
    
//     int i=1;
//     while(i<=10)
//     {
//         printf("%d\n",i);
//         i++;
//     }
//     return 0;   
    
// }   
    
    
    
    
    // {
            
    //         for(char i=65;i<=69;i++){
    //         for(char j=65;j<=i;j++){
    //             printf("%c",j);
    //         }
    //         printf("\n");
    //     }
    //     return 0;
    // }
    
    
    // {
            
    //         for(char i=65;i<=69;i++){
    //         for(char j=65;j<=i;j++){
    //             printf("%c",j);
    //         }
    //         printf("\n");
    //     }
    //     return 0;
    // }
    
    // {
    //         int n =1;
    //         for(int i=1;i<=5;i++){
    //         for(int j=1;j<=i;j++){
    //             printf("%d",n++);
    //         }
    //         printf("\n");
    //     }
    //     return 0;
    // }
    
    // {
    //         for(int i=5;i>=1;i--){
    //         for(int j=5;j>=i;j--){
    //             printf("%d",i);
    //         }
    //         printf("\n");
    //     }
    //     return 0;
    // }
    
    
    // {
    //         for(int i=1;i<=5;i++){
    //         for(int j=1;j<=i;j++){
    //             printf("%d",i);
    //         }
    //         printf("\n");
    //     }
    //     return 0;
    // }
    
    
    
    
    // {
            for(int i=0;i<=4;i++){
            for(int j=0;j<=i;j++){
                printf("%d",j+1);
            }
            printf("\n");
        }
        return 0;
    }
    
    
    
    
    
    // int i,c;
    
    // printf("enter even number:");
    // scanf("%d",&c);

    // for(i=2;i<=c;i +=2)
    // {
    //     printf("%d \n",i);
        
    // }
    // return 0;
 
// }   
    
    // int i,c;
    
    // printf("enter odd number:");
    // scanf("%d",&c);

    // for(i=1;i<=c;i++)
    // {
    //     if(i%2!=0)
    //     {
    //         printf("%d \n",i);
    //     }
    // }
    // return 0;
    
    
    // int i,c;
    // for(i=0;i<=10;i++)
    // {
    // printf("%d\n",i);
    // c=c+i;
    // }
    // printf("%d ",c);
    
    // return 0;
    
    
    
    // char c;
    // for (c = 97; c <= 122; c++)
    
    //     printf("%c - %c \n",c-32, c);
    
    // return 0;
    
    // char c;
    // for (c = 65; c <= 90; c++)
    //     printf("%c - %d \n",c, c);
    // return 0;
    
    
    // char c;
    // for (c = 'A'; c <= 'Z'; ++c)
    //     printf("%c", c);
    // return 0;
    
    
    // int a,n;
    
    // printf("enter number:");
    // scanf("%d",&n);
    
    // for(a=n;a>=1;a--)
    // {
    // printf("%d\n",a);
    // }
    
    // return 0;
    
    
    
    
    // int a,n;
    
    // printf("enter number:");
    // scanf("%d",&n);
    
    // for(a=1;a<=n;a++)
    // {
    // printf("%d\n",a);
    // }
    
    // return 0;
    
    
    
    
    // int a;
    // for(a=51;a<99;a++)
    // {
    // printf("%d\n",a);
    // }
    
    // return 0;
// }
    
    
    
    
//     int a,b,p;
//     printf("Enter the number:");
//     scanf("%d",&a);
    
//     printf("Enter the number:");
//     scanf("%d",&b);
    
//     p = pow(a,b);
//     printf("%d",p);
    
    
//  return 0;   
// }    
    
    
    
//     int principal,rate,t,intr;
//     printf("enter the principal:");
//     scanf("%d",&principal);
    
//     printf("enter the rate:");
//     scanf("%d",&rate);
    
//     printf("enter the time:");
//     scanf("%d",&t);
    
//     intr = (principal*rate*t)/100;
//     printf("the simpal intre is:%d",intr);
    
    
//  return 0;   
// }    
    
    
    
    
    
//     int a,cube;
//         printf("enter the number");
//         scanf("%d",&a);
        
//         cube= a*a*a;
//         printf("cube:%d",cube);
    
    
//  return 0;   
// }    
    
//     int num1, num2;
//     float avg;

//     printf("enter first number: ");
//     scanf("%d",&num1);
//     printf("enter second number: ");
//     scanf("%d",&num2);
    
//     avg= (num1+num2)/2;

    
//     printf("average of %d and %d is: %f",num1,num2,avg);

//   return 0;
// }

  
  
  
    // char ch;
    
    // printf("Enter any alphabet: ");
    // scanf("%c", &ch);
    
    // switch (ch) {
    //     case 'a':
    //     case 'e':
    //     case 'i':
    //     case 'o':
    //     case 'u':
    //     case 'A':
    //     case 'E':
    //     case 'I':
    //     case 'O':
    //     case 'U':
    //         printf("%c is a vowel.\n", ch);
    //         break;
    //     default:
    //         printf("%c is a consonant.\n", ch);
    // }
    
//     return 0;
// }

    // int a=20;
    // printf("%d\n",a++);
    // printf("%d\n",--a);
    // printf("%d\n",a++);
    // printf("%d\n",--a);
    // printf("%d\n",a++);

    // return 0;
    
//     char  'a';
//     printf("%c",a);
    
    
    
// }
    // int main() {
       
    //   int chr=97;
    //     printf(" %c\n", chr);
        
        
    //     return 0;
    // }
    



